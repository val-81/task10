﻿using System;

namespace task10
{
    class Сorner
    {
        public double gradus;
        public double min;
        public double sec;
        public double Radian;

        public void Enter()
        {
            Console.WriteLine("Введите число градусов угла");
            this.gradus = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите число минут угла");
            this.min = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите число секунд угла");
            this.sec = Convert.ToDouble(Console.ReadLine());
        }
        public void ToRadians()
        {
            double Radian = (gradus + min / 60 + sec / 3600) * (Math.PI) / 180;
            Console.WriteLine("Угол радиан = " + Radian);
        }
    }
 }
